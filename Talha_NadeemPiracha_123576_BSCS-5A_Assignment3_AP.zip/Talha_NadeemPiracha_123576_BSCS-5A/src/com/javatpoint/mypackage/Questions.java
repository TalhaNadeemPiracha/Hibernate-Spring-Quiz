package com.javatpoint.mypackage;

public class Questions {
	
	private int id;
	private String question_title;
	private String option1;
	private String option2;
	private String option3;
	private String option4;
	
	Questions(){
		
	}
	
	public int getId(){
		return this.id;
	}
	
	public void setId(int id){
		this.id = id;
	}
	
public void setTitle(String question_title)
{
	this.question_title=question_title;
}
public String getTitle()
{
	return question_title;
}
public void set_option1(String option1)
{
	this.option1=option1;
}
public String get_option1()
{
	return option1;
}
public void set_option2(String option2)
{
	this.option2=option2;
}
public String get_option2()
{
	return option2;
}
public void set_option3(String option3)
{
	this.option3=option3;
}
public String get_option3()
{
	return option3;
}
public void set_option4(String option4)
{
	this.option4=option4;
}
public String get_option4()
{
	return option4;
}


}
