package com.javatpoint.mypackage;

import java.util.List;

public class Quiz {

	private int id;
	private String title;
	private String description;
	private List<Questions> list;
	
	public Quiz(){
		
	}
	
	public int getId(){
		return this.id;
	}
	
	public void setId(int id){
		this.id = id;
	}
	
	public String getTitle(){
		return this.title;
	}
	
	public void setTitle(String title){
		this.title = title;
	}
	
	public String getDescription(){
		return this.description;
	}
	
	public void setDescription(String description){
		this.description = description;
	}
	
	public List<Questions> getList(){
		return this.list;
	}
	
	public void setList(List<Questions> list){
		this.list = list;
	}
}
