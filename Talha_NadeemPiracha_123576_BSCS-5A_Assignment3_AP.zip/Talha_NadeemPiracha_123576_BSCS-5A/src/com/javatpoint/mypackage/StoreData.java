package com.javatpoint.mypackage;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StoreData {
public static void main(String[] args) {
	

	//creating configuration object
	Configuration cfg=new Configuration();
	cfg.configure("hibernate.cfg.xml");//populates the data of the configuration file
	
	//creating seession factory object
	SessionFactory factory=cfg.buildSessionFactory();
	
	//creating session object
	Session session=factory.openSession();
	
	//creating transaction object
	Transaction t=session.beginTransaction();
	
	User1 u1=new User1();
	Questions q1=new Questions();
	
	Scanner user_input= new Scanner(System.in);
	
	 int option;
	 int choice;
	 
	 
	System.out.println("Welcome to the quiz application: ");
	System.out.println("Press 1 for Signup. Press 2 for Signin.");
	option=user_input.nextInt();
	if(option==1)
	{
	System.out.println("Welcome to the SIGNUP page: ");
	System.out.println("Enter your name:");
	u1.setName(user_input.nextLine());
	u1.setmail(user_input.nextLine());
	u1.setpassword(user_input.nextLine());
	u1.setRole(user_input.nextLine());
	session.persist(u1);
	t.commit();
	session.close();
	}
	
		
	if(option==2)
	{
	System.out.println("Welcome to the SIGNIN page: ");
	System.out.println("Enter your email id: ");
	/**/
	System.out.println("Enter your password: ");
	/**/
	
	/*
	*/
	
	System.out.println("Welcome to the Panel.Press 3 if you want to create a quiz: ");
	choice=user_input.nextInt();
	if(choice==3)
	{
	System.out.println("Enter question title: ");
	q1.setTitle(user_input.nextLine());
	q1.set_option1(user_input.nextLine());
	q1.set_option2(user_input.nextLine());
	q1.set_option3(user_input.nextLine());
	q1.set_option4(user_input.nextLine());
	
	
	}
		
	
	System.out.println("successfully saved");
	

}
}

}